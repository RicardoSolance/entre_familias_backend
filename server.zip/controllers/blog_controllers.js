const blog_model = require('../models/blog_model');






const obj = {
    createBlog,
    editBlog,
    deleteUser,
    getAllBlogs
}

module.exports = obj;